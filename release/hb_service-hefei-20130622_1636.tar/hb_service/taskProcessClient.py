# -*- coding:gbk -*-
# auther : pdm
# email : ppppdm@gmail.com


def sendCmdToServer(ip_list, arg_list):
    
    # connect to server
    
    
    # send to server
    
    
    # close connect
    
    
    return False


if __name__=='__main__':
    print(__file__, 'test')
